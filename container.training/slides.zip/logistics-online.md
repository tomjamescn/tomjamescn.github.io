## Intros

- Hello! We are:

   - .emoji[👷🏻‍♀️] AJ ([@s0ulshake], [EphemeraSearch])

   - .emoji[🐳] Jérôme ([@jpetazzo], Enix SAS)

- The training will run for 4 hours, with a 10 minutes break every hour

  (the middle break will be a bit longer)

- Feel free to ask questions at any time

- *Especially when you see full screen container pictures!*

- Live feedback, questions, help: @@CHAT@@

[EphemeraSearch]: https://ephemerasearch.com/
[@s0ulshake]: https://twitter.com/s0ulshake
[@jpetazzo]: https://twitter.com/jpetazzo