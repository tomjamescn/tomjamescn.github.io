# Exercise — writing Dockerfiles

Let's write Dockerfiles for an existing application!

The code is at: https://github.com/jpetazzo/wordsmith
